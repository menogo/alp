// prettier.config.js or .prettierrc.js
module.exports = {
  trailingComma: 'none',
  tabWidth: 2,
  semi: false,
  singleQuote: true
}

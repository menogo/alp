const API = {
  google: 'https://api.github.com/user/google'
}

export default API
